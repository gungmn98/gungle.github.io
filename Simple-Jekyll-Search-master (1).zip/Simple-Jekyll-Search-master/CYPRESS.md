# Cypress

```bash
npm i
```

run example blog with jekyll search build

```bash
cd example
jekyll serve
```

run cypress tests

```bash
npm run cypress run
# or
npm run cypress open
```
